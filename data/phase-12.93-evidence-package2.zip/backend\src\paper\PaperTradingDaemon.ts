import type { Repositories } from "../db/repositories/index.js";
import { nowMs } from "../db/utils/timestamps.js";
import { DynamicRatchetService } from "../exits/DynamicRatchetService.js";
import type {
  CohortTier,
  DynamicRatchetConfig,
  ExitReasonCode,
  MarketEvaluationContext,
  PositionRatchetState,
  RatchetEvaluationResult,
} from "../exits/DynamicRatchetTypes.js";
import { CandidateScannerEvaluator } from "../candidate-scanner/CandidateScannerEvaluator.js";
import { CANDIDATE_SCANNER_DEFAULTS } from "../candidate-scanner/CandidateScannerConfig.js";
import type {
  CandidateScannerRuntimeConfig,
  ScannedPoolRecord,
} from "../candidate-scanner/CandidateScannerTypes.js";
import type { HistoricalSessionSummary, HistoricalTrade } from "@nexustrade/shared";

export type DaemonHaltReason =
  | "PORTFOLIO_DRAWDOWN_BREACHED"
  | "CONSECUTIVE_ERRORS_EXCEEDED"
  | "CLOCK_DRIFT_EXCEEDED"
  | "MANUAL_STOP"
  | "DURATION_ELAPSED"
  | "SCHEDULE_WINDOW_CONCLUDED";

export interface TradingScheduleConfig {
  readonly startMinutes: number;
  readonly endMinutes: number;
  readonly timeZone: string;
  readonly rawString: string;
}

export function parseScheduleString(scheduleStr: string): TradingScheduleConfig | undefined {
  const trimmed = scheduleStr.trim();
  const match = /^(\d{1,2}:\d{2})-(\d{1,2}:\d{2})(?::([a-zA-Z0-9_/]+))?$/.exec(trimmed);
  if (!match) {
    console.warn(
      `[PaperDaemon] Invalid --schedule format: "${scheduleStr}". Expected HH:MM-HH:MM[:TZ] (e.g. 07:00-17:30:PDT)`,
    );
    return undefined;
  }
  const startStr = match[1];
  const endStr = match[2];
  const rawTz = match[3];
  if (!startStr || !endStr) return undefined;

  const startParts = startStr.split(":");
  const endParts = endStr.split(":");
  const sh = Number(startParts[0]);
  const sm = Number(startParts[1]);
  const eh = Number(endParts[0]);
  const em = Number(endParts[1]);

  if (
    !Number.isFinite(sh) ||
    !Number.isFinite(sm) ||
    !Number.isFinite(eh) ||
    !Number.isFinite(em)
  ) {
    return undefined;
  }

  if (sh < 0 || sh > 23 || sm < 0 || sm > 59 || eh < 0 || eh > 23 || em < 0 || em > 59) {
    console.warn(`[PaperDaemon] Invalid hour/minute in --schedule: "${scheduleStr}"`);
    return undefined;
  }
  const startMinutes = sh * 60 + sm;
  const endMinutes = eh * 60 + em;

  let timeZone = "America/Los_Angeles";
  if (rawTz) {
    const upperTz = rawTz.toUpperCase();
    if (upperTz === "PDT" || upperTz === "PST" || upperTz === "PT" || upperTz === "PACIFIC") {
      timeZone = "America/Los_Angeles";
    } else if (
      upperTz === "EDT" ||
      upperTz === "EST" ||
      upperTz === "ET" ||
      upperTz === "EASTERN"
    ) {
      timeZone = "America/New_York";
    } else if (
      upperTz === "CDT" ||
      upperTz === "CST" ||
      upperTz === "CT" ||
      upperTz === "CENTRAL"
    ) {
      timeZone = "America/Chicago";
    } else if (
      upperTz === "MDT" ||
      upperTz === "MST" ||
      upperTz === "MT" ||
      upperTz === "MOUNTAIN"
    ) {
      timeZone = "America/Denver";
    } else if (upperTz === "UTC" || upperTz === "GMT") {
      timeZone = "UTC";
    } else {
      timeZone = rawTz;
    }
  }

  try {
    new Intl.DateTimeFormat("en-US", { timeZone });
  } catch {
    console.warn(
      `[PaperDaemon] Unrecognized timezone "${rawTz}", falling back to "America/Los_Angeles"`,
    );
    timeZone = "America/Los_Angeles";
  }

  return {
    startMinutes,
    endMinutes,
    timeZone,
    rawString: scheduleStr,
  };
}

export function isWithinTradingSchedule(
  timestampMs: number,
  schedule: TradingScheduleConfig,
): { isWithin: boolean; currentMinutes: number; minutesUntilNext: number } {
  const date = new Date(timestampMs);
  const formatter = new Intl.DateTimeFormat("en-US", {
    timeZone: schedule.timeZone,
    hour12: false,
    hour: "numeric",
    minute: "numeric",
  });
  const parts = formatter.formatToParts(date);
  const hour = parseInt(parts.find((p) => p.type === "hour")?.value ?? "0", 10);
  const minute = parseInt(parts.find((p) => p.type === "minute")?.value ?? "0", 10);
  const currentMinutes = (hour % 24) * 60 + minute;

  let isWithin = false;
  if (schedule.startMinutes <= schedule.endMinutes) {
    isWithin = currentMinutes >= schedule.startMinutes && currentMinutes < schedule.endMinutes;
  } else {
    isWithin = currentMinutes >= schedule.startMinutes || currentMinutes < schedule.endMinutes;
  }

  let minutesUntilNext = 0;
  if (!isWithin) {
    if (schedule.startMinutes <= schedule.endMinutes) {
      if (currentMinutes < schedule.startMinutes) {
        minutesUntilNext = schedule.startMinutes - currentMinutes;
      } else {
        minutesUntilNext = 24 * 60 - currentMinutes + schedule.startMinutes;
      }
    } else {
      minutesUntilNext =
        currentMinutes < schedule.startMinutes
          ? schedule.startMinutes - currentMinutes
          : 24 * 60 - currentMinutes + schedule.startMinutes;
    }
  }

  return { isWithin, currentMinutes, minutesUntilNext };
}

export interface PaperTradingDaemonConfig {
  readonly sessionId: string;
  readonly durationHours: number;
  readonly maxOpenPositions: number;
  readonly positionSizeSol: number;
  readonly initialPortfolioSol: number;
  readonly maxPortfolioDrawdownBps: number; // default -500 (-5.0%)
  readonly maxConsecutiveErrors: number; // default 3
  readonly maxClockDriftMs: number; // default 5000 (5s)
  readonly pollIntervalMs: number; // default 1000ms
  readonly dryRun: boolean;
  readonly scannerConfig?: CandidateScannerRuntimeConfig;
  readonly antiRebuyCooldownMs?: number; // default: 1800000 (30m)
  readonly uninterruptedResearchMode?: boolean; // default: false
  readonly tradingSchedule?: TradingScheduleConfig | undefined;
}

export interface PaperPosition {
  readonly positionId: string;
  readonly mintAddress: string;
  readonly symbol?: string | undefined;
  entryPriceSol: number;
  initialTokensHeld?: number;
  initialCostBasisSol?: number;
  readonly cohort?: CohortTier | undefined;
  readonly ratchetConfig?: DynamicRatchetConfig | undefined;
  tokensHeld: number;
  costBasisSol: number;
  realizedProceedsSol?: number;
  readonly openedAtMs: number;
  spotPriceSol: number;
  currentPnlBps: number;
  ratchetState: PositionRatchetState;
  lastActivityMs: number;
  stagnantTicksCount: number;
  pyramided?: boolean | undefined;
  scaleInCount?: number | undefined;
  tier1ProfitTaken?: boolean | undefined;
  tier2ProfitTaken?: boolean | undefined;
  peakGainBps?: number | undefined;
}

export interface ClosedTradeRecord {
  readonly positionId: string;
  readonly mintAddress: string;
  readonly symbol?: string | undefined;
  readonly entryPriceSol: number;
  readonly exitPriceSol: number;
  readonly costBasisSol: number;
  readonly proceedsSol: number;
  readonly realizedPnlSol: number;
  readonly realizedPnlBps: number;
  readonly peakGainBps?: number | undefined;
  readonly exitReason: string;
  readonly openedAtMs: number;
  readonly closedAtMs: number;
}

export type DaemonStatus =
  | "IDLE"
  | "RUNNING"
  | "PAUSED"
  | "EXITING"
  | "COMPLETED"
  | "STOPPED"
  | "HALTED";

export interface PaperTradingDaemonSnapshot {
  readonly sessionId: string;
  readonly status: DaemonStatus;
  readonly haltReason?: DaemonHaltReason | undefined;
  readonly openPositions: readonly PaperPosition[];
  readonly closedTrades: readonly ClosedTradeRecord[];
  readonly initialPortfolioSol: number;
  readonly currentPortfolioSol: number;
  readonly totalRealizedPnlSol: number;
  readonly totalUnrealizedPnlSol: number;
  readonly maxOpenPositions: number;
  readonly consecutiveErrorCount: number;
  readonly startedAtMs: number;
  readonly lastTickAtMs: number;
}

export interface PaperTradingDaemonOptions {
  readonly config: PaperTradingDaemonConfig;
  readonly repositories?: Repositories;
  readonly ratchetService?: DynamicRatchetService;
  readonly scannerEvaluator?: CandidateScannerEvaluator;
  readonly clock?: () => number;
}

export class PaperTradingDaemon {
  private readonly config: PaperTradingDaemonConfig;
  private readonly scannerConfig: CandidateScannerRuntimeConfig;
  private readonly ratchetService: DynamicRatchetService;
  private readonly scannerEvaluator: CandidateScannerEvaluator;
  private readonly clock: () => number;

  private status: DaemonStatus = "IDLE";
  private haltReason: DaemonHaltReason | undefined;
  private consecutiveErrorCount = 0;
  private readonly startedAtMs: number;
  private lastTickAtMs: number;

  private currentCashSol: number;
  private readonly openPositions = new Map<string, PaperPosition>();
  private readonly closedTrades: ClosedTradeRecord[] = [];
  private readonly exitCooldowns = new Map<string, number>();

  constructor(options: PaperTradingDaemonOptions) {
    this.config = options.config;
    this.scannerConfig = options.config.scannerConfig ?? CANDIDATE_SCANNER_DEFAULTS;
    this.ratchetService = options.ratchetService ?? new DynamicRatchetService();
    this.scannerEvaluator = options.scannerEvaluator ?? new CandidateScannerEvaluator();
    this.clock = options.clock ?? nowMs;

    this.currentCashSol = this.config.initialPortfolioSol;
    this.startedAtMs = this.clock();
    this.lastTickAtMs = this.startedAtMs;
  }

  start(): void {
    if (this.status === "RUNNING") return;
    this.status = "RUNNING";
    this.haltReason = undefined;
  }

  pause(): void {
    if (this.status === "RUNNING") {
      this.status = "PAUSED";
    }
  }

  resume(): void {
    if (this.status === "PAUSED") {
      this.status = "RUNNING";
    }
  }

  startExiting(): void {
    if (this.status === "HALTED" || this.status === "STOPPED" || this.status === "COMPLETED") {
      return;
    }
    if (this.openPositions.size === 0) {
      this.status = "COMPLETED";
    } else {
      this.status = "EXITING";
    }
  }

  stop(reason: DaemonHaltReason = "MANUAL_STOP"): void {
    this.status = reason === "MANUAL_STOP" ? "STOPPED" : "HALTED";
    this.haltReason = reason;
  }

  getCurrentCashSol(): number {
    return this.currentCashSol;
  }

  scaleInPosition(
    positionId: string,
    addOnCostBasisSol: number,
    spotPriceSol: number,
    nowTimestampMs?: number,
  ): PaperPosition | null {
    if (this.status !== "RUNNING") return null;
    const position = this.openPositions.get(positionId);
    if (!position) return null;

    // P0-06: Disallow scaling in after profit-taking has begun or if already pyramided
    if (position.tier1ProfitTaken || position.tier2ProfitTaken || position.pyramided) {
      return null;
    }

    if (addOnCostBasisSol <= 0 || spotPriceSol <= 0 || !Number.isFinite(spotPriceSol)) {
      return null;
    }

    if (this.currentCashSol < addOnCostBasisSol) {
      return null;
    }

    const now = nowTimestampMs ?? this.clock();
    const tokensToAdd = addOnCostBasisSol / spotPriceSol;

    position.tokensHeld += tokensToAdd;
    position.costBasisSol += addOnCostBasisSol;
    position.initialTokensHeld =
      (position.initialTokensHeld ?? position.tokensHeld - tokensToAdd) + tokensToAdd;
    position.initialCostBasisSol =
      (position.initialCostBasisSol ?? position.costBasisSol - addOnCostBasisSol) +
      addOnCostBasisSol;

    const blendedEntryPriceSol = position.costBasisSol / position.tokensHeld;
    position.entryPriceSol = blendedEntryPriceSol;
    position.spotPriceSol = spotPriceSol;
    position.currentPnlBps = Math.round(
      ((spotPriceSol - blendedEntryPriceSol) / blendedEntryPriceSol) * 10_000,
    );
    position.pyramided = true;
    position.scaleInCount = (position.scaleInCount ?? 0) + 1;
    position.lastActivityMs = now;

    this.currentCashSol -= addOnCostBasisSol;

    // P0-07: Adjust & Rebase ratchet state against new blended cost basis
    const rebasedPeakPriceSol = Math.max(spotPriceSol, blendedEntryPriceSol);
    const rebasedPeakGainBps = Math.max(
      0,
      Math.round(((rebasedPeakPriceSol - blendedEntryPriceSol) / blendedEntryPriceSol) * 10_000),
    );
    const updatedRatchetState: PositionRatchetState = {
      ...position.ratchetState,
      entryPriceSol: blendedEntryPriceSol,
      peakPriceSol: rebasedPeakPriceSol,
      peakGainBps: rebasedPeakGainBps,
      currentStopFloorBps: Math.max(0, position.ratchetState.currentStopFloorBps),
      armedBreakeven: true,
      lastEvaluatedAtMs: now,
    };
    position.ratchetState = updatedRatchetState;
    this.ratchetService.getStore().update(updatedRatchetState);

    return position;
  }

  manualExit(
    positionId: string,
    currentSpotPriceSol?: number,
    nowTimestampMs?: number,
    exitReason: string = "MANUAL_OPERATOR_EXIT",
  ): ClosedTradeRecord | null {
    const position = this.openPositions.get(positionId);
    if (!position) return null;

    const now = nowTimestampMs ?? this.clock();
    const exitPriceSol = currentSpotPriceSol ?? position.spotPriceSol;
    const finalProceedsSol = position.tokensHeld * exitPriceSol;
    this.currentCashSol += finalProceedsSol;

    const totalProceedsSol = (position.realizedProceedsSol ?? 0) + finalProceedsSol;
    const totalCostBasisSol = position.initialCostBasisSol ?? position.costBasisSol;
    const totalTokensSold = position.initialTokensHeld ?? position.tokensHeld;
    const vwapExitPriceSol =
      totalTokensSold > 0 ? totalProceedsSol / totalTokensSold : exitPriceSol;
    const realizedPnlSol = totalProceedsSol - totalCostBasisSol;
    const realizedPnlBps = Math.round((realizedPnlSol / totalCostBasisSol) * 10_000);

    const closedRecord: ClosedTradeRecord = {
      positionId: position.positionId,
      mintAddress: position.mintAddress,
      entryPriceSol: position.entryPriceSol,
      exitPriceSol: vwapExitPriceSol,
      costBasisSol: totalCostBasisSol,
      proceedsSol: totalProceedsSol,
      realizedPnlSol,
      realizedPnlBps,
      peakGainBps:
        position.peakGainBps ?? position.ratchetState?.peakGainBps ?? Math.max(realizedPnlBps, 0),
      exitReason,
      openedAtMs: position.openedAtMs,
      closedAtMs: now,
      ...(position.symbol !== undefined ? { symbol: position.symbol } : {}),
    };

    this.closedTrades.push(closedRecord);
    this.openPositions.delete(positionId);
    this.ratchetService.getStore().delete(positionId);

    const cooldownMs = this.config.antiRebuyCooldownMs ?? 1800000;
    this.exitCooldowns.set(position.mintAddress, now + cooldownMs);

    if (this.status === "EXITING" && this.openPositions.size === 0) {
      this.status = this.haltReason ? "HALTED" : "COMPLETED";
    }

    return closedRecord;
  }

  getSnapshot(): PaperTradingDaemonSnapshot {
    const openPositionsArray = Array.from(this.openPositions.values());
    const totalUnrealizedPnlSol = openPositionsArray.reduce((acc, pos) => {
      const currentValSol = pos.tokensHeld * pos.spotPriceSol;
      return acc + (currentValSol - pos.costBasisSol);
    }, 0);

    const partialRealizedFromOpenPositions = openPositionsArray.reduce((acc, pos) => {
      const initialCost = pos.initialCostBasisSol ?? pos.costBasisSol;
      const costRelieved = initialCost - pos.costBasisSol;
      const realizedProceeds = pos.realizedProceedsSol ?? 0;
      return acc + (realizedProceeds - costRelieved);
    }, 0);

    const totalRealizedPnlSol =
      this.closedTrades.reduce((acc, trade) => acc + trade.realizedPnlSol, 0) +
      partialRealizedFromOpenPositions;

    const totalPositionEquitySol = openPositionsArray.reduce(
      (acc, pos) => acc + pos.tokensHeld * pos.spotPriceSol,
      0,
    );

    const currentPortfolioSol = this.currentCashSol + totalPositionEquitySol;

    return {
      sessionId: this.config.sessionId,
      status: this.status,
      ...(this.haltReason ? { haltReason: this.haltReason } : {}),
      openPositions: openPositionsArray,
      closedTrades: [...this.closedTrades],
      initialPortfolioSol: this.config.initialPortfolioSol,
      currentPortfolioSol,
      totalRealizedPnlSol,
      totalUnrealizedPnlSol,
      maxOpenPositions: this.config.maxOpenPositions,
      consecutiveErrorCount: this.consecutiveErrorCount,
      startedAtMs: this.startedAtMs,
      lastTickAtMs: this.lastTickAtMs,
    };
  }

  public heartbeat(nowTimestampMs?: number): void {
    this.lastTickAtMs = nowTimestampMs ?? this.clock();
  }

  processScannedPool(
    pool: ScannedPoolRecord,
    nowTimestampMs?: number,
    entryPriceSolOverride?: number,
    positionSizeSolOverride?: number,
    options?: {
      bypassScannerEvaluation?: boolean;
      cohort?: CohortTier;
      ratchetConfig?: DynamicRatchetConfig;
    },
  ): boolean {
    if (this.status !== "RUNNING") return false;
    const now = nowTimestampMs ?? this.clock();

    // 1. Position Sizing & Capacity Check
    if (this.openPositions.size >= this.config.maxOpenPositions) {
      return false;
    }
    const positionSize =
      positionSizeSolOverride !== undefined ? positionSizeSolOverride : this.config.positionSizeSol;

    if (this.currentCashSol < positionSize || positionSize <= 0) {
      return false;
    }

    // 1b. Single Position Per Mint Check
    for (const openPos of this.openPositions.values()) {
      if (openPos.mintAddress === pool.mintAddress) {
        return false;
      }
    }

    // 1c. Anti-Rebuy Cooldown Check
    const cooldownUntilMs = this.exitCooldowns.get(pool.mintAddress);
    if (cooldownUntilMs !== undefined && now < cooldownUntilMs) {
      return false;
    }

    // 2. Anti-Rug & L/MC Evaluation Check
    if (!options?.bypassScannerEvaluation) {
      const nowSec = Math.floor(now / 1000);
      const evaluation = this.scannerEvaluator.evaluate(pool, this.scannerConfig, nowSec);
      if (!evaluation.admitted) {
        return false;
      }
    }

    // 3. Execute Paper Buy
    const positionId = `pos-${pool.mintAddress}-${now}`;
    const entryPriceSol =
      entryPriceSolOverride !== undefined ? entryPriceSolOverride : pool.spotPriceUsd;

    // Discard non-positive or non-finite entry prices
    if (!entryPriceSol || entryPriceSol <= 0 || !Number.isFinite(entryPriceSol)) {
      return false;
    }

    const initialTokensHeld = positionSize / entryPriceSol;
    const initialCostBasisSol = positionSize;

    this.currentCashSol -= initialCostBasisSol;

    const ratchetState = this.ratchetService
      .getStore()
      .initPositionState(positionId, pool.mintAddress, entryPriceSol, now);

    const position: PaperPosition = {
      positionId,
      mintAddress: pool.mintAddress,
      entryPriceSol,
      initialTokensHeld,
      initialCostBasisSol,
      tokensHeld: initialTokensHeld,
      costBasisSol: initialCostBasisSol,
      realizedProceedsSol: 0,
      openedAtMs: now,
      spotPriceSol: entryPriceSol,
      currentPnlBps: 0,
      ratchetState,
      lastActivityMs: now,
      stagnantTicksCount: 0,
      ...(pool.symbol !== undefined ? { symbol: pool.symbol } : {}),
      ...(options?.cohort !== undefined ? { cohort: options.cohort } : {}),
      ...(options?.ratchetConfig !== undefined ? { ratchetConfig: options.ratchetConfig } : {}),
    };

    this.openPositions.set(positionId, position);
    return true;
  }

  tickPosition(
    positionId: string,
    marketContext: MarketEvaluationContext,
    nowTimestampMs?: number,
  ): RatchetEvaluationResult | null {
    if (this.status !== "RUNNING" && this.status !== "PAUSED" && this.status !== "EXITING") {
      return null;
    }
    const now = nowTimestampMs ?? this.clock();
    this.lastTickAtMs = now;

    const position = this.openPositions.get(positionId);
    if (!position) return null;

    try {
      // 1. Clock Drift Safety Tripwire
      if (Math.abs(now - marketContext.currentTimestampMs) > this.config.maxClockDriftMs) {
        this.stop("CLOCK_DRIFT_EXCEEDED");
        throw new Error(
          `Clock drift violation: diff ${Math.abs(now - marketContext.currentTimestampMs)}ms > max ${this.config.maxClockDriftMs}ms`,
        );
      }

      // 2. Inactivity Tracking & 5-Minute Stagnancy Timeout
      const priceChanged = Math.abs(marketContext.spotPriceSol - position.spotPriceSol) > 1e-9;
      const hasRecentActivity =
        (marketContext.recentBuysCount60s ?? 0) > 0 ||
        (marketContext.recentSellsCount60s ?? 0) > 0 ||
        !marketContext.volumeStalled3m;

      if (priceChanged || hasRecentActivity) {
        position.lastActivityMs = now;
        position.stagnantTicksCount = 0;
      } else {
        position.stagnantTicksCount += 1;
      }

      // If position has had no activity for >= 3 minutes (180,000ms), force stagnancy exit
      if (now - position.lastActivityMs >= 180_000) {
        const exitPriceSol = marketContext.spotPriceSol;
        const finalProceedsSol = position.tokensHeld * exitPriceSol;
        this.currentCashSol += finalProceedsSol;

        const totalProceedsSol = (position.realizedProceedsSol ?? 0) + finalProceedsSol;
        const totalCostBasisSol = position.initialCostBasisSol ?? position.costBasisSol;
        const totalTokensSold = position.initialTokensHeld ?? position.tokensHeld;
        const vwapExitPriceSol =
          totalTokensSold > 0 ? totalProceedsSol / totalTokensSold : exitPriceSol;
        const realizedPnlSol = totalProceedsSol - totalCostBasisSol;
        const realizedPnlBps = Math.round((realizedPnlSol / totalCostBasisSol) * 10_000);

        const closedRecord: ClosedTradeRecord = {
          positionId: position.positionId,
          mintAddress: position.mintAddress,
          entryPriceSol: position.entryPriceSol,
          exitPriceSol: vwapExitPriceSol,
          costBasisSol: totalCostBasisSol,
          proceedsSol: totalProceedsSol,
          realizedPnlSol,
          realizedPnlBps,
          exitReason: "STAGNANCY_TIMEOUT_EXIT",
          openedAtMs: position.openedAtMs,
          closedAtMs: now,
          ...(position.symbol !== undefined ? { symbol: position.symbol } : {}),
        };

        this.closedTrades.push(closedRecord);
        this.openPositions.delete(positionId);
        this.ratchetService.getStore().delete(positionId);

        const cooldownMs = this.config.antiRebuyCooldownMs ?? 1800000;
        this.exitCooldowns.set(position.mintAddress, now + cooldownMs);

        if (this.status === "EXITING" && this.openPositions.size === 0) {
          this.status = "COMPLETED";
        }

        return {
          action: "SELL_ALL",
          reasonCode: "STAGNANCY_TIMEOUT_EXIT" as unknown as ExitReasonCode,
          diagnostics: {
            currentPnlBps: realizedPnlBps,
            peakGainBps: position.ratchetState.peakGainBps,
            currentStopFloorBps: position.ratchetState.currentStopFloorBps,
            activeTier: position.ratchetState.activeTier,
            drawdownState: position.ratchetState.drawdownState,
            drawdownElapsedMs: null,
            lpIntact: marketContext.lpIntact,
            buySellRatio60s:
              marketContext.recentBuysCount60s / Math.max(1, marketContext.recentSellsCount60s),
            momentum5mBps: marketContext.momentum5mBps,
          },
          updatedState: position.ratchetState,
        };
      }

      // 3. Evaluate Dynamic Ratchet Stop-Loss Engine
      const prevPrice = position.spotPriceSol;
      const singleTickDropBps =
        marketContext.singleTickDropBps ??
        (prevPrice > 0
          ? Math.round(((marketContext.spotPriceSol - prevPrice) / prevPrice) * 10_000)
          : 0);

      const enrichedContext: MarketEvaluationContext = {
        ...marketContext,
        singleTickDropBps,
      };

      const result = this.ratchetService.evaluate(
        position.ratchetState,
        enrichedContext,
        position.ratchetConfig,
      );

      // Update position pricing state & track high-water mark
      position.spotPriceSol = marketContext.spotPriceSol;
      position.currentPnlBps = result.diagnostics.currentPnlBps;
      position.peakGainBps = Math.max(
        position.peakGainBps ?? 0,
        result.diagnostics.peakGainBps ?? 0,
      );
      position.ratchetState = result.updatedState;

      // 4. Handle Partial Scale-Out or Full Sell
      if (result.action === "SELL_PARTIAL_50") {
        position.tier1ProfitTaken = true;
        const initialTokens = position.initialTokensHeld ?? position.tokensHeld;
        const initialCost = position.initialCostBasisSol ?? position.costBasisSol;
        const tokensToSell = Math.min(position.tokensHeld, initialTokens * 0.5);
        if (tokensToSell > 0) {
          const proceedsSol = tokensToSell * marketContext.spotPriceSol;
          const costRelievedSol = (tokensToSell / initialTokens) * initialCost;
          position.tokensHeld -= tokensToSell;
          position.costBasisSol -= costRelievedSol;
          position.realizedProceedsSol = (position.realizedProceedsSol ?? 0) + proceedsSol;
          this.currentCashSol += proceedsSol;
        }
      } else if (result.action === "SELL_PARTIAL_25") {
        position.tier2ProfitTaken = true;
        const initialTokens = position.initialTokensHeld ?? position.tokensHeld;
        const initialCost = position.initialCostBasisSol ?? position.costBasisSol;
        const tokensToSell = Math.min(position.tokensHeld, initialTokens * 0.25);
        if (tokensToSell > 0) {
          const proceedsSol = tokensToSell * marketContext.spotPriceSol;
          const costRelievedSol = (tokensToSell / initialTokens) * initialCost;
          position.tokensHeld -= tokensToSell;
          position.costBasisSol -= costRelievedSol;
          position.realizedProceedsSol = (position.realizedProceedsSol ?? 0) + proceedsSol;
          this.currentCashSol += proceedsSol;
        }
      } else if (result.action === "SELL_ALL") {
        const exitPriceSol = marketContext.spotPriceSol;
        const finalProceedsSol = position.tokensHeld * exitPriceSol;
        this.currentCashSol += finalProceedsSol;

        const totalProceedsSol = (position.realizedProceedsSol ?? 0) + finalProceedsSol;
        const totalCostBasisSol = position.initialCostBasisSol ?? position.costBasisSol;
        const totalTokensSold = position.initialTokensHeld ?? position.tokensHeld;
        const vwapExitPriceSol =
          totalTokensSold > 0 ? totalProceedsSol / totalTokensSold : exitPriceSol;
        const realizedPnlSol = totalProceedsSol - totalCostBasisSol;
        const realizedPnlBps = Math.round((realizedPnlSol / totalCostBasisSol) * 10_000);

        const closedRecord: ClosedTradeRecord = {
          positionId: position.positionId,
          mintAddress: position.mintAddress,
          entryPriceSol: position.entryPriceSol,
          exitPriceSol: vwapExitPriceSol,
          costBasisSol: totalCostBasisSol,
          proceedsSol: totalProceedsSol,
          realizedPnlSol,
          realizedPnlBps,
          peakGainBps:
            position.peakGainBps ??
            position.ratchetState.peakGainBps ??
            Math.max(realizedPnlBps, 0),
          exitReason: result.reasonCode,
          openedAtMs: position.openedAtMs,
          closedAtMs: now,
          ...(position.symbol !== undefined ? { symbol: position.symbol } : {}),
        };

        this.closedTrades.push(closedRecord);
        this.openPositions.delete(positionId);
        this.ratchetService.getStore().delete(positionId);

        const cooldownMs = this.config.antiRebuyCooldownMs ?? 1800000;
        this.exitCooldowns.set(position.mintAddress, now + cooldownMs);

        if (this.status === "EXITING" && this.openPositions.size === 0) {
          this.status = this.haltReason ? "HALTED" : "COMPLETED";
        }
      }

      // 5. Portfolio Drawdown Circuit Breaker
      this.checkPortfolioCircuitBreakers();

      this.consecutiveErrorCount = 0;
      return result;
    } catch (err) {
      this.consecutiveErrorCount += 1;
      if (this.consecutiveErrorCount >= this.config.maxConsecutiveErrors) {
        this.stop("CONSECUTIVE_ERRORS_EXCEEDED");
      }
      throw err;
    }
  }

  recordStagnantTick(positionId: string, nowTimestampMs?: number): ClosedTradeRecord | null {
    const position = this.openPositions.get(positionId);
    if (!position) return null;
    const now = nowTimestampMs ?? this.clock();
    this.lastTickAtMs = now;
    position.stagnantTicksCount += 1;

    // Check if inactivity has reached 3 minutes (180,000ms)
    if (now - position.lastActivityMs >= 180_000) {
      const exitPriceSol = position.spotPriceSol;
      const finalProceedsSol = position.tokensHeld * exitPriceSol;
      this.currentCashSol += finalProceedsSol;

      const totalProceedsSol = (position.realizedProceedsSol ?? 0) + finalProceedsSol;
      const totalCostBasisSol = position.initialCostBasisSol ?? position.costBasisSol;
      const totalTokensSold = position.initialTokensHeld ?? position.tokensHeld;
      const vwapExitPriceSol =
        totalTokensSold > 0 ? totalProceedsSol / totalTokensSold : exitPriceSol;
      const realizedPnlSol = totalProceedsSol - totalCostBasisSol;
      const realizedPnlBps = Math.round((realizedPnlSol / totalCostBasisSol) * 10_000);

      const closedRecord: ClosedTradeRecord = {
        positionId: position.positionId,
        mintAddress: position.mintAddress,
        entryPriceSol: position.entryPriceSol,
        exitPriceSol: vwapExitPriceSol,
        costBasisSol: totalCostBasisSol,
        proceedsSol: totalProceedsSol,
        realizedPnlSol,
        realizedPnlBps,
        peakGainBps:
          position.peakGainBps ?? position.ratchetState?.peakGainBps ?? Math.max(realizedPnlBps, 0),
        exitReason: "STAGNANCY_TIMEOUT_EXIT",
        openedAtMs: position.openedAtMs,
        closedAtMs: now,
        ...(position.symbol !== undefined ? { symbol: position.symbol } : {}),
      };

      this.closedTrades.push(closedRecord);
      this.openPositions.delete(positionId);
      this.ratchetService.getStore().delete(positionId);

      const cooldownMs = this.config.antiRebuyCooldownMs ?? 1800000;
      this.exitCooldowns.set(position.mintAddress, now + cooldownMs);

      if (this.status === "EXITING" && this.openPositions.size === 0) {
        this.status = this.haltReason ? "HALTED" : "COMPLETED";
      }

      return closedRecord;
    }

    return null;
  }

  private checkPortfolioCircuitBreakers(): void {
    const snapshot = this.getSnapshot();
    const portfolioPnlBps = Math.round(
      ((snapshot.currentPortfolioSol - snapshot.initialPortfolioSol) /
        snapshot.initialPortfolioSol) *
        10_000,
    );

    if (portfolioPnlBps <= this.config.maxPortfolioDrawdownBps) {
      if (this.config.uninterruptedResearchMode) {
        this.haltReason = "PORTFOLIO_DRAWDOWN_BREACHED";
      } else {
        this.haltReason = "PORTFOLIO_DRAWDOWN_BREACHED";
        if (this.openPositions.size > 0) {
          // P0-04: Freeze new admissions and scale-ins while actively managing existing open risk
          this.status = "EXITING";
        } else {
          this.stop("PORTFOLIO_DRAWDOWN_BREACHED");
        }
      }
    }
  }

  getExitCooldowns(): ReadonlyMap<string, number> {
    return this.exitCooldowns;
  }

  getHistoricalSummary(stats?: {
    coinsWatchedCount?: number;
    missedOpportunitiesCount?: number;
  }): HistoricalSessionSummary {
    const snapshot = this.getSnapshot();
    const durationMinutes = Math.max(1, Math.round((this.lastTickAtMs - this.startedAtMs) / 60000));
    const netPnlSol = parseFloat(
      (snapshot.currentPortfolioSol - this.config.initialPortfolioSol).toFixed(4),
    );
    const netPnlPct = parseFloat(
      (
        ((snapshot.currentPortfolioSol - this.config.initialPortfolioSol) /
          this.config.initialPortfolioSol) *
        100
      ).toFixed(2),
    );

    const winsCount = this.closedTrades.filter((t) => t.realizedPnlSol > 0).length;
    const lossesCount = this.closedTrades.filter((t) => t.realizedPnlSol < 0).length;
    const scratchesCount = this.closedTrades.filter((t) => t.realizedPnlSol === 0).length;
    const totalTrades = this.closedTrades.length;
    const winRatePct =
      totalTrades > 0 ? parseFloat(((winsCount / totalTrades) * 100).toFixed(2)) : 0;

    const trades: HistoricalTrade[] = this.closedTrades.map((t) => ({
      tradeId: t.positionId,
      poolId: `pool-${t.mintAddress.slice(0, 8)}`,
      mintAddress: t.mintAddress,
      symbol: t.symbol ?? t.mintAddress.slice(0, 6).toUpperCase(),
      entryPriceSol: t.entryPriceSol,
      exitPriceSol: t.exitPriceSol,
      sizeSol: t.costBasisSol,
      enteredAt: new Date(t.openedAtMs).toISOString(),
      exitedAt: new Date(t.closedAtMs).toISOString(),
      holdDurationSeconds: Math.max(1, Math.round((t.closedAtMs - t.openedAtMs) / 1000)),
      peakGainBps: t.peakGainBps ?? Math.max(t.realizedPnlBps, 0),
      finalPnlBps: t.realizedPnlBps,
      finalPnlSol: parseFloat(t.realizedPnlSol.toFixed(4)),
      exitReason: t.exitReason,
      finalTier:
        t.realizedPnlBps >= 5000 ? "TIER_2" : t.realizedPnlBps >= 1500 ? "TIER_1" : "BASELINE",
    }));

    return {
      sessionId: this.config.sessionId,
      startedAt: new Date(this.startedAtMs).toISOString(),
      endedAt: new Date(this.lastTickAtMs).toISOString(),
      durationMinutes,
      startingCapitalSol: this.config.initialPortfolioSol,
      endingCapitalSol: parseFloat(snapshot.currentPortfolioSol.toFixed(4)),
      netPnlSol,
      netPnlPct,
      totalTrades,
      buysCount: totalTrades + this.openPositions.size,
      sellsCount: totalTrades,
      winsCount,
      lossesCount,
      scratchesCount,
      winRatePct,
      coinsWatchedCount: stats?.coinsWatchedCount ?? 0,
      missedOpportunitiesCount: stats?.missedOpportunitiesCount ?? 0,
      trades,
    };
  }
}
