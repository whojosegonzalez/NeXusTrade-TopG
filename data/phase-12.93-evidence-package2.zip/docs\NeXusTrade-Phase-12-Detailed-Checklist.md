# NeXusTrade Phase 12: Interactive Trading Dashboard & Control Plane Detailed Implementation Checklist

Status: **COMPLETED & VERIFIED**
Date: 2026-09-24
Author: Architecture & Implementation Team
Decision Owner: User / Human Reviewer
Governing Scope: [Phase 12 Scope Specification](file:///u:/Projects/TopG/docs/research-planning/phase-12-trading-dashboard-and-control-plane-scope.md)
Baseline Repository State: Phase 11 Verified (69 test files, 654 tests passing)
Final Verified State: Phase 12 Complete (73 test files, 697 tests passing: 675 backend, 22 frontend)

---

## 1. Overview & Architectural Blueprint

The purpose of Phase 12 is to build, integrate, and verify the full interactive **Trading Dashboard and Control Plane** according to the operator's 3-page vision:

```mermaid
flowchart TD
    subgraph UI ["Phase 12: 3-Page React Dashboard"]
        Nav["Navigation Bar (Tabs: Settings | Active Session | Past Sessions)"]
        Nav --> P1["1. Settings View"]
        Nav --> P2["2. Active Session View"]
        Nav --> P3["3. Past Sessions View"]

        P1 --> P1_W["Refresh Wallet Info (SOL & SPL Tokens)"]
        P1 --> P1_S["Concurrency Slider (1-10) & Sizing"]
        P1 --> P1_R["Gas Fee Reserve & Deployable SOL"]
        P1 --> P1_G["Goal Switch (% Gain vs Final SOL)"]

        P2 --> P2_T["Telemetry (Unrealized / Realized / Net PnL)"]
        P2 --> P2_C["Counters (Open, Closed, W / L / Scratch)"]
        P2 --> P2_G["Position Cards (Ratchet Badges & Stop Distance)"]
        P2 --> P2_A["Controls (Pause | Resume | Start Exiting)"]

        P3 --> P3_L["Session History Ledger"]
        P3 --> P3_E["Cumulative Equity Curve Chart"]
    end

    subgraph StateAndIPC ["State & IPC Engine"]
        ActiveState[".tmp/paper-session-active.json"]
        SettingsState[".tmp/dashboard-settings.json"]
        HistoryFiles["data/sessions/*.json"]
    end

    subgraph DaemonBackend ["Paper Trading Daemon Backend"]
        Daemon["PaperTradingDaemon & Runner"]
    end

    P1 <--> SettingsState
    P2 <--> ActiveState
    P3 <--> HistoryFiles
    Daemon <--> ActiveState
```

---

## 2. Ordered Implementation Tasks

### Part A: Interactive Dashboard & Visual Control Plane (Phase 12A)

#### Task 1: Shared Data Contracts & Schemas

- [x] Define type-safe Zod schemas in `shared/src/phase12-dashboard-schemas.ts`:
  - `DashboardSettingsSchema`:
    - `maxConcurrentPositions`: `z.number().int().min(1).max(10).default(3)`
    - `positionSizeSol`: `z.number().positive().default(1.0)`
    - `gasReserveSol`: `z.number().nonnegative().default(0.05)`
    - `goalMode`: `z.enum(["PERCENT_GAIN", "FINAL_SOL_BALANCE"]).default("PERCENT_GAIN")`
    - `targetGoalValue`: `z.number().positive().default(10.0)`
    - `walletAddress`: `z.string().default("")`
    - `strategyThresholds`: `z.object({ minLmcRatio: z.number().default(0.15), maxLmcRatio: z.number().default(0.30), minBuyToSellRatio: z.number().default(1.5), minVolume5mUsd: z.number().default(2500), minMaturityAgeSec: z.number().default(300), maxMaturityAgeSec: z.number().default(900) }).default({})`
  - `WalletTelemetrySchema`:
    - `solBalance`: `z.number().nonnegative()`
    - `deployableSol`: `z.number().nonnegative()`
    - `tokens`: array of `{ mint: string, symbol: string, amount: number, decimals: number }`
    - `signatureReady`: `z.boolean()`
    - `fetchedAt`: `z.string()`
  - `SessionControlCommandSchema`:
    - `action`: `z.enum(["PAUSE", "RESUME", "START_EXITING", "MANUAL_EXIT", "EMERGENCY_STOP"])`
    - `targetPositionId`: `z.string().optional()`
    - `issuedAt`: `z.number()`
- [x] Export schemas and TypeScript inference types from `shared/src/index.ts`.

---

#### Task 2: Backend Wallet Query & IPC Control Service

- [x] Create `backend/src/wallet/WalletTelemetryService.ts`:
  - Connects to Solana RPC to fetch native lamport balance via `getBalance`.
  - Parses SPL token accounts via `getTokenAccountsByOwner` with token program ID.
  - Formats balances and computes `deployableSol = Math.max(0, solBalance - gasReserveSol)`.
- [x] Create `backend/src/session/SessionControlIpcService.ts`:
  - Manages IPC communication between React UI and `PaperTradingDaemon`.
  - Reads and dispatches commands:
    - `PAUSE`: Halts new pool admissions in daemon.
    - `RESUME`: Re-enables pool admissions in daemon.
    - `START_EXITING`: Freezes admissions, sets daemon wind-down flag, waits for natural scratch or profit exits before stopping.
    - `MANUAL_EXIT`: Immediately triggers market close for a specific position.
    - `EMERGENCY_STOP`: Closes all open positions and halts daemon immediately.
- [x] Unit tests in `backend/src/wallet/WalletTelemetryService.test.ts` and `backend/src/session/SessionControlIpcService.test.ts`.

---

#### Task 3: Settings View (`frontend/src/views/SettingsView.tsx`)

- [x] Implement Settings View component:
  - **Wallet Header Card**:
    - "Refresh Wallet Info" button with loading state.
    - SOL Balance display and SPL token account list.
    - Connection / Signature readiness badge.
  - **Capital & Position Sizing Controls**:
    - Max Concurrent Positions slider (`1` to `10`) with synchronized numeric input.
    - Position Size text input in SOL.
  - **Gas Reserve & Available SOL Display**:
    - Gas Fee Reserve input (SOL).
    - Highlighted card showing: $\text{Deployable SOL} = \max(0, \text{Total SOL} - \text{Gas Reserve})$.
    - Max position capacity indicator: $\lfloor \text{Deployable SOL} / \text{Position Size} \rfloor$.
  - **Profit Goal Mode Switch**:
    - Toggle between `% Gain Goal` and `Final SOL Target`.
    - Input field for target value with validation.
    - Informational badge explaining auto-trigger of graceful wind-down when target is reached.
  - **Strategy Threshold Controls**:
    - Sliders and inputs for Min/Max L/MC, Min Buy/Sell ratio, Min 5m Volume.
  - **Save & Apply**: Persists settings to local storage / `.tmp/dashboard-settings.json`.
- [x] Unit test in `frontend/src/views/SettingsView.test.tsx`.

---

#### Task 4: Active Session View (`frontend/src/views/ActiveSessionView.tsx`)

- [x] Implement Active Session View component:
  - **Telemetry Banner**:
    - Session Status badge (`IDLE`, `RUNNING`, `PAUSED`, `EXITING`, `COMPLETED`).
    - Realized P/L ($SOL$ and `bps`/`%`).
    - Unrealized P/L ($SOL$ and `bps`/`%`).
    - Net Total Session P/L with color-coded profit/loss styling.
    - Session timer (Elapsed / Remaining).
  - **5-Stat Metric Counter Grid**:
    - Open Positions counter (e.g., `2 / 3`).
    - Closed Trades count.
    - Wins count ($\ge +1.0\%$).
    - Losses count ($< -1.0\%$).
    - Scratches count ($-1.0\%$ to $+1.0\%$).
  - **Open Positions Cards / Grid**:
    - Token symbol and truncated mint address.
    - Entry price & current spot price ($SOL$).
    - Real-time PnL ($SOL$ and `bps`/`%`).
    - **Ratchet Tier Badge**:
      - `ENTRY` (Initial stop $-12\%$).
      - `SCRATCH ARMED` ($+0.5\%$ gain reached).
      - `SMART HOLD` ($-8.0\%$ dip grace hold active).
      - `TIER 1 LOCKED` ($+20.0\%$ floor locked).
      - `TIER 2 LOCKED` ($+45.0\%$ floor locked).
    - **Stop-Loss Trigger Distance**:
      - Floor price in SOL.
      - Relative distance meter (e.g., `-3.8% away from stop`).
    - **Manual Exit Button**: One-click market close modal with confirmation.
  - **Candidate Watchlist / Radar Table**:
    - Live table of tokens currently on the Watchlist.
    - Real-time age, L/MC ratio, 5m buys/sells, and Buy Gate status (`WATCHING`, `BUY_TRIGGERED`, `DROPPED`).
  - **Session Control Suite**:
    - `PAUSE SESSION` button.
    - `RESUME SESSION` button.
    - `START EXITING` button (graceful wind-down mode).
    - `EMERGENCY STOP` button.
  - **Live Activity Feed**: Real-time log of buys, ratchet advancements, and sell executions.
- [x] Unit test in `frontend/src/views/ActiveSessionView.test.tsx`.

---

#### Task 5: Past Sessions & History View (`frontend/src/views/HistoryView.tsx`)

- [x] Implement Past Sessions View component:
  - **Historical Sessions Ledger Table**:
    - Columns: Session ID, Date/Time, Duration, Final Equity, Net PnL ($SOL$), Win Rate (%), Total Trades, W / L / Scratch counts.
    - Row expander showing individual trades for that session.
  - **Cumulative Equity Curve Chart**:
    - Interactive line chart tracking portfolio equity progression over historical sessions.
    - Annotations for starting capital and session milestones.
- [x] Unit test in `frontend/src/views/HistoryView.test.tsx`.

---

#### Task 6: Main Shell & Navigation Integration (`frontend/src/App.tsx`)

- [x] Update `frontend/src/App.tsx` with a top-level tabbed navigation bar:
  - Tab 1: `Active Session`
  - Tab 2: `Settings`
  - Tab 3: `Past Sessions`
  - Tab 4: `Archive Explorer`
- [x] Implement live data synchronization hook (`useLiveSessionState.ts`):
  - Polls `.tmp/paper-session-active.json` every 1,500ms with fallback handling.
  - Updates React state without UI jitter or layout shifts.
- [x] Add session goal evaluation hook:
  - Monitors portfolio equity against the configured goal (Mode A or Mode B).
  - Automatically emits `START_EXITING` action when goal is satisfied.
- [x] Component integration tests in `frontend/src/App.test.tsx`.

---

#### Task 7: Daemon Graceful "Start Exiting" Mode Support

- [x] Update `backend/src/paper/PaperTradingDaemon.ts`:
  - Add `startExiting(): void` method:
    - Sets state to `"EXITING"`.
    - Rejects all new pool admissions (`processScannedPool` returns `false`).
    - Continues ticking open positions through `DynamicRatchetService`.
    - Once `openPositions.size === 0`, marks status as `"COMPLETED"`.
  - Add `manualExit(positionId: string): void` method:
    - Immediately closes specified position at current spot price and logs reason code `MANUAL_OPERATOR_EXIT`.
- [x] Unit tests in `backend/src/paper/PaperTradingDaemon.test.ts`.

---

### Part B: Quantitative Strategy, Candidate Watchlist & Buy Gate Funnel (Phase 12B)

#### Task 8: Candidate Watchlist Radar Service (`backend/src/candidate-scanner/CandidateWatchlistService.ts`)

- [x] Decouple pool discovery from immediate execution by implementing an active candidate watchlist:
  - Stores up to `maxWatchlistSize` (e.g. 20) pre-screened tokens meeting baseline safety:
    - Liquidity $\ge \$2,500$
    - LP burn $\ge 90.0\%$
    - Mint & freeze authorities disabled
    - Unique txns $\ge 10$
  - Discards decaying pools: Automatically drops tokens when age exceeds $1,200\text{s}$ (20m) without triggering a buy.
- [x] Unit tests in `backend/src/candidate-scanner/CandidateWatchlistService.test.ts`.

---

#### Task 9: Quantitative Buy Gate Confirmation Engine (`backend/src/candidate-scanner/BuyGateTriggerService.ts`)

- [x] Implement active multi-condition confirmation for tokens on the watchlist:
  - **Maturity Window Gate**: $300\text{s} \le \text{Age} \le 900\text{s}$ (5m to 15m sweet spot).
  - **Depth Balance Gate**: $0.15 \le \text{L/MC} \le 0.30$ (healthy liquidity vs. market cap).
  - **Flow Absorption Gate**: $\text{Buys}_{5m} \ge 1.5 \times \text{Sells}_{5m}$ (organic buyer dominance).
  - **Volume Surge Gate**: $\text{Volume}_{5m} \ge \$2,500$ with average transaction $\ge \$25$.
  - **Dev Disposal Gate**: Verifies no single transaction disposed $> 5\%$ of pool depth in the last 3 minutes.
- [x] Promotes confirmed candidate to the `PaperTradingDaemon` buy queue.
- [x] Unit tests in `backend/src/candidate-scanner/BuyGateTriggerService.test.ts`.

---

#### Task 10: Multi-Source Pool Discovery Streamer Integration

- [x] Enhance `CandidateStreamEngine.ts` with multi-source ingestion:
  - Primary: Raydium AMM / CLMM / CPMM pools.
  - Secondary: DexScreener latest token profiles (`https://api.dexscreener.com/token-profiles/latest/v1`) to capture newly launched pump.fun migrations and fresh Solana pairs.
- [x] Unit tests in `backend/src/candidate-scanner/CandidateStreamEngine.test.ts`.

---

### Part C: Verification & Deployment

#### Task 11: End-to-End Verification & Operator Guide

- [x] Run full static isolation checks: `node scripts/verify-isolated.mjs static`.
- [x] Run full test suites: `node scripts/verify-isolated.mjs tests`.
- [x] Verify 100% clean passes across all workspaces.
- [x] Update `README.md` and operator guides with dashboard launch instructions:

  ```powershell
  # Start the React Trading Dashboard
  pnpm dev:frontend

  # Access in browser at http://localhost:5173
  ```

---

## 3. Part D: Algorithmic Hardening & Empirical Calibration Sub-Phases (12.2 – 12.88)

Status: **COMPLETED & ACTIVE IN PRODUCTION**  
Active In Live Session: `session-paper-12.88-01`

### Sub-Phase 12.2 – 12.10: Continuous Virtual Wallet & State Persistence

- [x] Implemented `ContinuousVirtualWallet.ts` in `backend/src/paper/`:
  - Retains and compounds profits across daemon sessions without resetting to default 10.0 SOL.
  - Flushes state atomically to `.tmp/virtual-wallet.json`.
  - Computes dynamic position sizing proportional to equity ($0.25$ to $0.35$ SOL for micro probes, $1.00$ to $1.25$ SOL for established runners).
- [x] Integrated real-time counterfactual tracking (`CounterfactualTracker.ts`) to log what would have happened if stopped trades were held for 15m, 30m, 60m.

### Sub-Phase 12.11 – 12.30: Multi-Tier Dynamic Ratchet & Moonbag Architecture

- [x] Hardened `DynamicRatchetService.ts` with multi-tier scaling:
  - **Tier 1 Scale-Out**: Sells 50% of tokens at $+20.0\%$ gain, ratcheting stop floor to $+10.0\%$.
  - **Tier 2 Scale-Out**: Sells 25% of tokens at $+48.5\%$ gain, ratcheting stop floor to $+35.0\%$.
  - **Trailing Moonbag**: Floats stop floor at $\text{Peak} \times 0.75$ ($25\%$ trailing buffer) on the final 25% tokens.
- [x] Breakeven Scratch Exits: Arms breakeven floor at $+0.5\%$ gain; liquidates at $\sim 0\%$ to $+1\%$ if momentum stalls $> 180\text{s}$.
- [x] Verified empirically across 100+ live tick simulations.

### Sub-Phase 12.31 – 12.50: Emergency Circuit Breakers & Dump Protection

- [x] Authored Single-Tick Whale Dump Cliff Cut (`WHALE_DEV_DUMP_CLIFF_CUT`):
  - Detects single-tick drops $\le -10.0\%$ with 0 recent buys and unrealized $\text{PnL} \le -8.0\%$.
  - Triggers instant `SELL_ALL`, bypassing normal stop slippage to avoid total rugs.
- [x] Authored Avalanche Sell-Pressure Cut (`EMERGENCY_SELL_PRESSURE_CUT`):
  - Detects sell transaction surges ($\ge 25$ sells in 60s, $\text{sells} \ge 2 \times \text{buys}$) with $\text{PnL} \le -3.0\%$.
  - Immediately liquidates at minimal loss ($-2.9\%$ cuts).

### Sub-Phase 12.51 – 12.70: Retest Pullback Gate & Organic Flow Protection

- [x] Created Retest Pullback Buy Gate (`Gate 11` in `BuyGateTriggerService.ts`):
  - Blocks buying local tops/pumps.
  - Requires token to retest and pull back $5.0\%$ to $12.0\%$ below its recent peak.
  - Requires positive buyer absorption during the dip ($\text{Buys}_{5m} \ge 1.2 \times \text{Sells}_{5m}$).
- [x] Wash-Trading Shield:
  - Rejects tokens where volume is generated by a small cluster of repetitive wallets ($< 50$ unique traders).

### Sub-Phase 12.71 – 12.84: Cohort Bifurcation & 250 Holder Floor

- [x] Formalized Established Runner vs. Micro-Cap Probe cohorts:
  - **Established Runners**: $\text{Liquidity} \ge \$50,000$, $\text{Age} \ge 30\text{m}$, $\text{Holders} \ge 250$.
  - **Micro-Cap Probes**: $\text{Liquidity} \ge \$20,000$, $\text{Age} \ge 5\text{m}$, $\text{Holders} \ge 100$.
- [x] Raised Verified Holder Floor:
  - Raised minimum verified holders from 100 to **250** for established runner triggers to filter out bot pools with fake distribution.

### Sub-Phase 12.85 – 12.87: Candidate Established Decoupling & Moonbag Extraction

- [x] Fixed Candidate Established Gate decoupling bug:
  - Pre-screening candidate established pools no longer inherits legacy candidate scanner constraints.
  - Allowed high-liquidity established tokens to enter the radar and trigger buys.
- [x] Validated monumental runner gains in live sessions:
  - `BANDIT`: $+72.4\%$ gain ($+0.362$ SOL realized).
  - `SACC`: $+84.0\%$ gain ($+0.420$ SOL realized).

### Sub-Phase 12.88: 12-Hour Multi-Regime Live Calibration Session

- [x] Patched CLI argument parser in `backend/src/scripts/paper-trading-daemon.ts` to accept `--duration <N>` alongside `--duration-hours <N>`.
- [x] Launched multi-regime empirical calibration session `session-paper-12.88-01` with `--duration 12`.
- [x] Real-time session metrics: Portfolio peaked at `10.8758 SOL`, drawdown circuit breaker halted cleanly at `10.1429 SOL` (-6.74%) after 9.1 hours.
- [x] Completed forensic audit identifying fake liquidity pools (`test`, `SAPLING`) and sizing clamp on established runners.

### Sub-Phase 12.89: Sizing Unlock & RugCheck Defense Hardening

- [x] **Unlocked Established Compounding Sizing**:
  - Eliminated static 1.0 SOL clamp in `paper-trading-daemon.ts` so established entries dynamically scale to `1.0 * walletScale` (up to 1.25 SOL) as wallet equity compounds.
- [x] **Fail-Closed RugCheck Across All Cohorts**:
  - Enforced `requireVerifiedHolders: true` uniformly across both Micro-Caps and Established candidates, preventing unverified bot-farm pools with phantom liquidity from bypassing holder distribution checks.
- [x] **Hardcoded Symbol Integrity Blacklist**:
  - Implemented `REJECTED_BLACKLISTED_SYMBOL` gate in `BuyGateTriggerService.ts` blocking `TEST`, `TEST1`, `TEST2`, `TESTCOIN`, `NULL`, `UNDEFINED`, `PUMP`, `SOL`, `WSOL`.
- [x] **Counterfactual Opportunity Tracker Unit Normalization**:
  - Normalized initial price intake (`pool.spotPriceUsd / 140`) and added unit outlier guards in `CounterfactualOpportunityTracker.ts` to eliminate synthetic billion-percent gain/drop reporting artifacts.
- [x] **Verification & Isolation Audit**:
  - Executed `scripts/verify-isolated.mjs` (tsc, eslint, prettier, architecture check, check-secrets, and all Vitest configurations) with 100% passing tests.

### Sub-Phase 12.90: Chrono-Regime 7-Day Scheduler & Continuous Virtual Wallet

- [x] **Chrono-Regime Scheduler Engine**:
  - Added CLI flag `--schedule "HH:mm-HH:mm[:TZ]"` (e.g., `--schedule "07:00-18:00:PDT"`) in `paper-trading-daemon.ts`.
  - Supports automatic window startup, active/wall clock accounting, periodic hourly heartbeats, and graceful end-of-window liquidation (`SCHEDULE_WINDOW_CONCLUDED`).
- [x] **Continuous Virtual Wallet State Persistence**:
  - Persists wallet balance, all-time PnL, and session history to `.tmp/virtual-wallet.json`.
  - Realistic multi-day equity compounding across daemon restarts with optional `--wallet-reset` flag.
- [x] **Operational Benchmarks**:
  - Successfully executed Day 1 and Day 2 scheduled trading sessions with zero runtime crashes.

### Sub-Phase 12.91 & 12.92: Observation Analytics Engine & Multi-Day Benchmarking

- [x] **Paper Observation Analytics Engine**:
  - Created `backend/src/scripts/paper-observation-analytics.ts` (`pnpm daemon:analytics`).
  - Forensic tracking of executed paper buys, pre-screen filtered candidates, missed winners ($\ge +15\%$), and avoided rugs ($\le -30\%$) with filter attribution.
- [x] **Trade History Exporter & Backtest Simulator**:
  - Created `scripts/export-trade-history.mjs` exporting 178+ historical trades across 16 sessions to CSV (`data/trade-history-2026-09-27-to-2026-10-12.csv`).
  - Created `scripts/simulate-all-historical-patches.mjs` validating cumulative performance uplift of all patches (+81.5% net compounding uplift).
- [x] **Multi-Day Benchmark Execution**:
  - Completed Day 3 scheduled benchmark on PC (`session-paper-12.92-day3`) and 61.8-hour continuous run on Fedora laptop (`session-paper-fedora-7d`).

### Sub-Phase 12.93: Turbo-Defense & Execution Hardening

- [x] **Moonbag Capital-Preservation Guarantee**:
  - Added `MOONBAG_PROTECTION_EXIT` in `DynamicRatchetService.ts`: post-Tier-1 tranches immediately exit if spot price falls below $-2.0\%$ of cost basis.
  - Guarantees any trade taking Tier 1 profit closes net green ($+0.09\text{ SOL}$ minimum net gain on $1.0\text{ SOL}$).
- [x] **Scaled-In Breakeven Blended Shield**:
  - Added `SCALED_BREAKEVEN_EXIT` in `DynamicRatchetService.ts` and `PaperTradingDaemon.ts`: pyramided positions immediately arm breakeven on blended cost basis, exiting at $0.0\%$ if momentum stalls.
- [x] **Universal Strict Pre-Breakeven Cut**:
  - Added `UNCONFIRMED_PRE_BREAKEVEN_CUT`: cuts any unconfirmed position dropping $\le -12.0\%$ regardless of previous peak gain.
- [x] **1500ms Parallel High-Frequency Poller**:
  - Decoupled open position monitoring loop (1500ms ticker via `Promise.all`) from discovery scanning (5000ms), eliminating tick lag and price gap slippage.
- [x] **Calibrated Probe Sizing**:
  - Set default base probes to $0.50\text{ SOL}$ for Established and $0.35\text{ SOL}$ for Micro-Caps.
- [x] **Verification & Parallel Deployment**:
  - All 769 tests pass across all Vitest suites (`scripts/verify-isolated.mjs all`).
  - Master strategy documents exported (`docs/strategy_set/nexus_trading_strategy_set` and `phase_12_93_implementation_specification` in MD, DOCX, and PDF).
  - Deployed to 24/7 Fedora endurance runner (`session-paper-fedora-phase1293` in `tmux` with 10.0000 SOL clean baseline) and PC scheduled Day 4 runner.
