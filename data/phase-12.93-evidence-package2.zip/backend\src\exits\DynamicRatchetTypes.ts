export type RatchetTier =
  | "HARD_STOP"
  | "TIER_0_DRAWDOWN"
  | "SCRATCH"
  | "RUNNING"
  | "TIER_1"
  | "TIER_2";

export type DrawdownState = "NORMAL" | "EVALUATING_DRAWDOWN";

export type ExitActionType = "HOLD" | "SELL_ALL" | "SELL_PARTIAL_50" | "SELL_PARTIAL_25";

export type ExitReasonCode =
  | "HOLD_NORMAL"
  | "HOLD_DRAWDOWN_GRACE"
  | "CATASTROPHIC_HARD_STOP"
  | "RUG_PULL_DETECTED"
  | "SELL_PRESSURE_UNABSORBED"
  | "PROBE_UNCONFIRMED_DUMP_CUT"
  | "UNCONFIRMED_PRE_BREAKEVEN_CUT"
  | "MOONBAG_PROTECTION_EXIT"
  | "SCALED_BREAKEVEN_EXIT"
  | "EMERGENCY_SELL_PRESSURE_CUT"
  | "WHALE_DEV_DUMP_CLIFF_CUT"
  | "DRAWDOWN_GRACE_EXPIRED"
  | "SCRATCH_EXIT"
  | "ARMED_BREAKEVEN_BREACH"
  | "RATCHET_TIER_1_TRIGGERED"
  | "RATCHET_TIER_1_BREACH"
  | "RATCHET_TIER_2_TRIGGERED"
  | "RATCHET_TIER_2_BREACH"
  | "HARD_TAKE_PROFIT_CAP_TRIGGERED"
  | "SESSION_DURATION_CASHOUT"
  | "STAGNANCY_TIMEOUT_EXIT"
  | "MANUAL_OPERATOR_EXIT";

export interface PositionRatchetState {
  readonly positionId: string;
  readonly mintAddress: string;
  readonly entryPriceSol: number;
  readonly peakPriceSol: number;
  readonly peakGainBps: number;
  readonly currentStopFloorBps: number;
  readonly activeTier: RatchetTier;
  readonly drawdownState: DrawdownState;
  readonly drawdownEnteredAtMs: number | null;
  readonly lastEvaluatedAtMs: number;
  readonly tier1ProfitTaken?: boolean | undefined;
  readonly tier2ProfitTaken?: boolean | undefined;
  readonly armedBreakeven?: boolean | undefined;
}

export interface MarketEvaluationContext {
  readonly spotPriceSol: number;
  readonly lpIntact: boolean;
  readonly recentBuysCount60s: number;
  readonly recentSellsCount60s: number;
  readonly momentum5mBps: number;
  readonly volumeStalled3m: boolean;
  readonly currentTimestampMs: number;
  readonly singleTickDropBps?: number | undefined;
}

export interface RatchetEvaluationDiagnostics {
  readonly currentPnlBps: number;
  readonly peakGainBps: number;
  readonly currentStopFloorBps: number;
  readonly activeTier: RatchetTier;
  readonly drawdownState: DrawdownState;
  readonly drawdownElapsedMs: number | null;
  readonly lpIntact: boolean;
  readonly buySellRatio60s: number;
  readonly momentum5mBps: number;
}

export interface RatchetEvaluationResult {
  readonly action: ExitActionType;
  readonly reasonCode: ExitReasonCode;
  readonly diagnostics: RatchetEvaluationDiagnostics;
  readonly updatedState: PositionRatchetState;
}

export interface DynamicRatchetConfig {
  readonly catastrophicFloorBps: number; // default -1200 (-12.0%)
  readonly preBreakevenStopBps?: number | undefined; // Phase 12.93: default -1000 (-10.0% universal pre-breakeven hard stop)
  readonly moonbagFloorBps?: number | undefined; // Phase 12.93: default 0 (0.0% floor on remaining moonbag after Tier 1)
  readonly drawdownTriggerBps: number; // default -800 (-8.0%)
  readonly drawdownRecoveryBps: number; // default -500 (-5.0%)
  readonly drawdownGracePeriodMs: number; // default 120_000 (120s)
  readonly scratchPnlMinBps: number; // default 50 (+0.5%)
  readonly scratchPnlMaxBps: number; // default 150 (+1.5%)
  readonly armedBreakevenThresholdBps: number; // default 1000 (+10.0%)
  readonly armedBreakevenFloorBps: number; // default 0 (Breakeven +0.0% floor)
  readonly tier1PeakThresholdBps: number; // default 2000 (+20.0%)
  readonly tier1LockedFloorBps: number; // default 1000 (+10.0% floor on remaining 50%)
  readonly tier2PeakThresholdBps: number; // default 4850 (+48.5%)
  readonly tier2LockedFloorBps: number; // default 3500 (+35.0% floor on remaining 25%)
  readonly hardTakeProfitBps?: number | undefined; // optional hard take-profit cap
}

export const DEFAULT_DYNAMIC_RATCHET_CONFIG: DynamicRatchetConfig = {
  catastrophicFloorBps: -1200,
  preBreakevenStopBps: -1000,
  moonbagFloorBps: -200,
  drawdownTriggerBps: -800,
  drawdownRecoveryBps: -500,
  drawdownGracePeriodMs: 120_000,
  scratchPnlMinBps: 50,
  scratchPnlMaxBps: 150,
  armedBreakevenThresholdBps: 1000,
  armedBreakevenFloorBps: 0,
  tier1PeakThresholdBps: 2000,
  tier1LockedFloorBps: 1000,
  tier2PeakThresholdBps: 4850,
  tier2LockedFloorBps: 3500,
};

export type CohortTier = "MICRO_CAP" | "ESTABLISHED";

export const MICRO_CAP_DYNAMIC_RATCHET_CONFIG: DynamicRatchetConfig = {
  catastrophicFloorBps: -2000, // -20.0% catastrophic disaster floor
  preBreakevenStopBps: -1200, // Phase 12.93: -12.0% universal pre-breakeven stop
  moonbagFloorBps: -200, // Phase 12.93: -2.0% moonbag cliff guard floor
  drawdownTriggerBps: -600, // -6.0% drawdown warning
  drawdownRecoveryBps: -300, // -3.0% recovery
  drawdownGracePeriodMs: 90_000, // 90s base grace period for fast micro-cap dump protection
  scratchPnlMinBps: 50, // +0.5%
  scratchPnlMaxBps: 150, // +1.5%
  armedBreakevenThresholdBps: 1000, // +10.0% arm breakeven floor (+0.0%) with 0% sold
  armedBreakevenFloorBps: 0, // Breakeven (+0.0%) floor
  tier1PeakThresholdBps: 2000, // +20.0% take-profit Tier 1 (sell 50%, lock floor to +10.0%)
  tier1LockedFloorBps: 1000, // +10.0% floor on remaining 50%
  tier2PeakThresholdBps: 4850, // +48.5% take-profit Tier 2 (sell 25%, lock floor to +35.0%)
  tier2LockedFloorBps: 3500, // +35.0% floor
};

export const ESTABLISHED_DYNAMIC_RATCHET_CONFIG: DynamicRatchetConfig = {
  catastrophicFloorBps: -1800, // -18.0% catastrophic disaster floor
  preBreakevenStopBps: -1000, // Phase 12.93: -10.0% universal pre-breakeven stop
  moonbagFloorBps: -200, // Phase 12.93: -2.0% moonbag cliff guard floor
  drawdownTriggerBps: -800, // -8.0% drawdown warning
  drawdownRecoveryBps: -400, // -4.0% recovery
  drawdownGracePeriodMs: 120_000, // 120s grace period
  scratchPnlMinBps: 50, // +0.5%
  scratchPnlMaxBps: 150, // +1.5%
  armedBreakevenThresholdBps: 1000, // +10.0% arm breakeven floor (+0.0%) with 0% sold
  armedBreakevenFloorBps: 0, // Breakeven (+0.0%) floor
  tier1PeakThresholdBps: 2000, // +20.0% take-profit Tier 1 (sell 50%, lock floor to +10.0%)
  tier1LockedFloorBps: 1000, // +10.0% floor on remaining 50%
  tier2PeakThresholdBps: 4850, // +48.5% take-profit Tier 2 (sell 25%, lock floor to +35.0%)
  tier2LockedFloorBps: 3500, // +35.0% floor
};
